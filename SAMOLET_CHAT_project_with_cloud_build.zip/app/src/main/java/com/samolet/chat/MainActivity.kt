package com.samolet.chat

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val navy = Color.rgb(10, 22, 48)
    private val panel = Color.rgb(20, 38, 72)
    private val accent = Color.rgb(75, 150, 255)
    private val white = Color.WHITE
    private val muted = Color.rgb(174, 190, 215)
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showChats()
    }

    private fun base(): LinearLayout {
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(navy)
            setPadding(20, 22, 20, 16)
        }
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }
    }

    private fun showChats() {
        val root = base()
        val title = text("✈ САМОЛЁТ ЧАТ", 25f, white, true)
        root.addView(title)
        root.addView(text("Твои сообщения", 14f, muted).apply {
            setPadding(2, 5, 0, 18)
        })

        val search = EditText(this).apply {
            hint = "Поиск чатов"
            setHintTextColor(muted)
            setTextColor(white)
            textSize = 16f
            setSingleLine(true)
            setPadding(16, 12, 16, 12)
            setBackgroundColor(panel)
        }
        root.addView(search, LinearLayout.LayoutParams(-1, -2))

        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        addChat("Алексей", "Привет! Как дела?", "12:45", "2")
        addChat("Друзья", "Кто сегодня играет?", "Вчера", "")
        addChat("Семья", "Не забудь написать", "Пн", "")

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, 12, 0, 0)
        }
        bottom.addView(navButton("Чаты") { showChats() }, LinearLayout.LayoutParams(0, 52, 1f))
        bottom.addView(navButton("Контакты") { showInfo("Контакты", "Пока здесь пусто. Добавление друзей появится в следующей версии.") }, LinearLayout.LayoutParams(0, 52, 1f))
        bottom.addView(navButton("Профиль") { showInfo("Профиль", "Профиль пользователя — в разработке.") }, LinearLayout.LayoutParams(0, 52, 1f))
        root.addView(bottom)
        setContentView(root)
    }

    private fun navButton(label: String, action: () -> Unit): Button {
        return Button(this).apply {
            text = label
            textSize = 12f
            setTextColor(white)
            setBackgroundColor(panel)
            setOnClickListener { action() }
        }
    }

    private fun addChat(name: String, message: String, time: String, unread: String) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 15, 16, 15)
            setBackgroundColor(panel)
        }
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        left.addView(text(name, 18f, white, true))
        left.addView(text(message, 14f, muted).apply { setPadding(0, 5, 0, 0) })
        row.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
        val right = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            addView(text(time, 12f, muted))
            if (unread.isNotEmpty()) {
                addView(text(unread, 12f, white, true).apply {
                    gravity = Gravity.CENTER
                    setPadding(8, 3, 8, 3)
                    setBackgroundColor(accent)
                })
            }
        }
        row.addView(right)
        card.addView(row)
        val params = LinearLayout.LayoutParams(-1, -2)
        params.setMargins(0, 12, 0, 0)
        list.addView(card, params)
        card.setOnClickListener { openChat(name) }
    }

    private fun openChat(name: String) {
        val root = base()
        val header = text("‹  $name", 22f, white, true)
        header.setOnClickListener { showChats() }
        root.addView(header)
        root.addView(text("Это демонстрационный чат. Сообщения пока хранятся только на экране.", 13f, muted).apply {
            setPadding(0, 10, 0, 15)
        })
        val history = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        history.addView(bubble("Привет! Добро пожаловать в САМОЛЁТ ЧАТ.", false))
        val scroll = ScrollView(this)
        scroll.addView(history)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val compose = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val input = EditText(this).apply {
            hint = "Написать сообщение..."
            setHintTextColor(muted)
            setTextColor(white)
            setSingleLine(true)
            setBackgroundColor(panel)
        }
        compose.addView(input, LinearLayout.LayoutParams(0, 52, 1f))
        val send = Button(this).apply {
            text = "➤"
            setTextColor(white)
            setBackgroundColor(accent)
        }
        compose.addView(send)
        send.setOnClickListener {
            val value = input.text.toString().trim()
            if (value.isNotEmpty()) {
                history.addView(bubble(value, true))
                input.text.clear()
            }
        }
        root.addView(compose)
        setContentView(root)
    }

    private fun bubble(message: String, mine: Boolean): TextView {
        return text(message, 15f, white).apply {
            setPadding(14, 11, 14, 11)
            setBackgroundColor(if (mine) accent else panel)
            val p = LinearLayout.LayoutParams(-2, -2)
            p.setMargins(if (mine) 55 else 0, 7, if (mine) 0 else 55, 7)
            layoutParams = p
        }
    }

    private fun showInfo(title: String, message: String) {
        val root = base()
        val back = text("‹  Назад", 18f, accent, true)
        back.setOnClickListener { showChats() }
        root.addView(back)
        root.addView(text(title, 25f, white, true).apply { setPadding(0, 25, 0, 12) })
        root.addView(text(message, 16f, muted))
        setContentView(root)
    }
}
